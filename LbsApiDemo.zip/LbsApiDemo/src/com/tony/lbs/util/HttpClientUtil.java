package com.tony.lbs.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

public class HttpClientUtil
{
	
	/**
	 * post 方式调用http接口
	 * 
	 * @param url
	 * @param params
	 * @return
	 */
	public static String callHttpForPost(String url, List<NameValuePair> params)
	{
		String resultStr = null;
		CloseableHttpClient httpclient = HttpClientBuilder.create().build();
		HttpPost httpPost = new HttpPost(url);
		try
		{
			httpPost.setEntity(new UrlEncodedFormEntity(params, "UTF-8"));
			HttpResponse httpResponse = httpclient.execute(httpPost);
			resultStr = EntityUtils.toString(httpResponse.getEntity(),
					ContentType.getOrDefault(httpResponse.getEntity())
							.getCharset().toString());
		}
		catch (UnsupportedEncodingException | ClientProtocolException e)
		{
			e.printStackTrace();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		return resultStr;
	}
	
	/**
	 * get方式调用http服务
	 * @param requestUrl
	 * @return
	 * @throws IOException
	 */
	public static String callHttpForGet(String requestUrl) throws IOException
	{
		String resultStr = null;
		CloseableHttpClient httpClient = HttpClientBuilder.create().build();//避免返回compressed格式的Entity出现乱码
		try
		{
			URL url = new URL(requestUrl);
			// 防止pageUrl中出现空格竖杠等特殊字符导致httpget请求失败
			URI uri = new URI(url.getProtocol(), url.getHost(), url.getPath(),
					url.getQuery(), null);
			HttpGet httpget = new HttpGet(uri);// 以get体式格式请求该URL
			httpget.setHeader("Content-type" , "text/html; charset=utf-8");
			HttpResponse responce = httpClient.execute(httpget);// 获得responce对象
			int resStatu = responce.getStatusLine().getStatusCode();// 返回码
			if (resStatu == HttpStatus.SC_OK)
			{
				HttpEntity entity = responce.getEntity();
				if (entity != null)
				{
					// 对返回的html代码进行解析
					//resultStr = EntityUtils.toString(entity, ContentType.getOrDefault(entity).getCharset().toString());
					String str = EntityUtils.toString(entity,"UTF-8");
					str = str.replaceAll("\"", "'");
//					String result = EntityUtils.toString(entity).replaceAll("\"", "'");
					resultStr = new String(str.getBytes(),"utf-8");
				}
			}
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
		finally
		{
			httpClient.close();
		}
		return resultStr;
	}
}
