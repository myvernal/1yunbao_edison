package com.tony.lbs;

import java.util.ArrayList;
import java.util.List;

import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;

import com.tony.lbs.util.HttpClientUtil;

public class LBSMain {

	static String lbsAK = "CTi1c9NS47QdaTdQFG4lP6A";

	static String url = "http://api.map.baidu.com/geodata/v3/geotable/create";

	public static void main(String[] args) throws Exception {
		System.out.println(lbsAK.length());
		
		//创建LBS云存储数据表
		//List<NameValuePair> params = getListParam();
		//String value = HttpClientUtil.callHttpForPost(url, params);
		//System.out.println(value);
		
		//查询LBS云存储数据表
//		String listStr = HttpClientUtil.callHttpForGet("http://api.map.baidu.com/geodata/v3/geotable/list?ak="+lbsAK);
		
		String listStr = HttpClientUtil.callHttpForGet("http://api.map.baidu.com/geosearch/v3/nearby?ak="+lbsAK+"&geotable_id=70609&location=116.392851,39.934791&radius=5000");
		System.out.println(listStr);
		String name = "{\"status\":0,\"total\":2,\"size\":2,\"contents\":[{\"title\":\"\u5317\u6d77\u516c\u56ed\u5317\u8def\",\"location\":[116.391319,39.935728],\"city\":\"\u5317\u4eac\u5e02\",\"create_time\":1404546060,\"geotable_id\":70609,\"address\":\"\u5317\u4eac\u5e02\u897f\u57ce\u533a\u7231\u6c11\u8857\",\"tags\":\"\u5317\u6d77\",\"province\":\"\u5317\u4eac\u5e02\",\"district\":\"\u897f\u57ce\u533a\",\"uid\":326389044,\"coord_type\":3,\"type\":0,\"distance\":167,\"weight\":0},{\"title\":\"\u5317\u6d77\u516c\u56ed\",\"location\":[116.394203,39.932498],\"city\":\"\u5317\u4eac\u5e02\",\"create_time\":1404545994,\"geotable_id\":70609,\"address\":\"\u5317\u4eac\u5e02\u897f\u57ce\u533a\u5927\u77f3\u4f5c\u80e1\u540c\",\"tags\":\"\u516c\u56ed\",\"province\":\"\u5317\u4eac\u5e02\",\"district\":\"\u897f\u57ce\u533a\",\"uid\":326381991,\"coord_type\":3,\"type\":0,\"distance\":279,\"weight\":0}]}";
		name = name.replaceAll("\"", "'");
//		String str = "{'status':0,'total':2,'size':2,'contents':[{'title':'\u5317\u6d77\u516c\u56ed\u5317\u8def','location':[116.391319,39.935728],'city':'\u5317\u4eac\u5e02','create_time':1404546060,'geotable_id':70609,'address':'\u5317\u4eac\u5e02\u897f\u57ce\u533a\u7231\u6c11\u8857','tags':'\u5317\u6d77','province':'\u5317\u4eac\u5e02','district':'\u897f\u57ce\u533a','uid':326389044,'coord_type':3,'type':0,'distance':167,'weight':0},{'title':'\u5317\u6d77\u516c\u56ed','location':[116.394203,39.932498],'city':'\u5317\u4eac\u5e02','create_time':1404545994,'geotable_id':70609,'address':'\u5317\u4eac\u5e02\u897f\u57ce\u533a\u5927\u77f3\u4f5c\u80e1\u540c','tags':'\u516c\u56ed','province':'\u5317\u4eac\u5e02','district':'\u897f\u57ce\u533a','uid':326381991,'coord_type':3,'type':0,'distance':279,'weight':0}]}";
		System.out.println(new String(name.getBytes(), "utf-8"));
	}

	private static List<NameValuePair> getListParam() {
		List<NameValuePair> list = new ArrayList<NameValuePair>();
		list.add(new BasicNameValuePair("name", "房屋1信息"));
		list.add(new BasicNameValuePair("geotype", "1"));
		list.add(new BasicNameValuePair("is_published", "1"));
		list.add(new BasicNameValuePair("timestamp", ""));
		list.add(new BasicNameValuePair("ak", lbsAK));
		return list;
	}
	
}
