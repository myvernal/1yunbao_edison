package com.tony.lbs.service;

public interface GeotableService {

}
