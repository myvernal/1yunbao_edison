package com.tony.lbs.service.impl;

import com.tony.lbs.service.GeotableService;

public class GeotableServiceImpl implements GeotableService {

}
