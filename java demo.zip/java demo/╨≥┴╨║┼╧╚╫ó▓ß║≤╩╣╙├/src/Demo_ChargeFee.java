import java.io.UnsupportedEncodingException;
/**
 * 充值方法
 * @author acer
 *
 */

public class Demo_ChargeFee {
	public static void main()throws UnsupportedEncodingException{
		//输入您的软件序列号和密码
		String sn="";
		String pwd="";

		Client client=new Client(sn,pwd);
		
		//充值，参数依次为充值卡号和密码
		String result_charge = client.chargeFee("充值卡号", "充值卡密码");
		if (result_charge.startsWith("-")) {
			System.out.print(result_charge);
		}else {
			System.out.print("充值成功,最新余额为：" + client.getBalance() + "条");
		}
	}
	
}
