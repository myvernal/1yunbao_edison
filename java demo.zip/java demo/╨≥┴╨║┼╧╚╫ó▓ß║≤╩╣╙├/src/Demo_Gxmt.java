import java.io.UnsupportedEncodingException;


/**
 * 发送个性短信,即给不同的手机号发不同的内容,短信内容和手机号用英文的逗号对应好
 * @author acer
 *
 */
public class Demo_Gxmt {
	
	public static void main(String[] args) throws UnsupportedEncodingException {
		//输入软件序列号和密码
		String sn="";
		String pwd="";
		Client client=new Client(sn,pwd);		
		//个性短信发送		
		String result_mt = client.gxmt("手机号1,手机号2", "短信内容1,短信内容2", "", "", "");
		//输出返回标识
		System.out.print(result_mt);
	}
}
