import java.io.UnsupportedEncodingException;


public class Demo_UDPPwd {
//该Demo是更改密码
	public static void main()throws UnsupportedEncodingException{
		//输入您的软件序列号和密码
		String sn="DXX-OFT-010-xxxx";
		String pwd="123456";

		Client client=new Client(sn,pwd);
		
		//充值，参数依次为充值卡号和密码
		String result_charge = client.UDPPwd("173736");
		System.out.println(result_charge);
	}
}
